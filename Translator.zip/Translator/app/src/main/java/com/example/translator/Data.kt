package com.example.translator

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Languages offered by Google's on-device translation that suit this app. Code first, then the name shown. */
val LANGS: List<Pair<String, String>> = listOf(
    "en" to "English",
    "hi" to "Hindi",
    "mr" to "Marathi",
    "gu" to "Gujarati",
    "bn" to "Bengali",
    "ta" to "Tamil",
    "te" to "Telugu",
    "kn" to "Kannada",
    "ur" to "Urdu",
    "ar" to "Arabic",
    "fr" to "French",
    "de" to "German",
    "es" to "Spanish",
    "it" to "Italian",
    "pt" to "Portuguese",
    "ru" to "Russian",
    "ja" to "Japanese",
    "ko" to "Korean",
    "zh" to "Chinese"
)

fun langName(code: String): String = LANGS.firstOrNull { it.first == code }?.second ?: code

/** One finished translation kept in the history list. */
data class Entry(val from: String, val to: String, val source: String, val result: String)

object Store {
    private const val PREFS = "translator"
    private const val KEY = "history"

    fun load(ctx: Context): List<Entry> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
            ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = mutableListOf<Entry>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Entry(o.getString("f"), o.getString("t"), o.getString("s"), o.getString("r")))
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(ctx: Context, list: List<Entry>) {
        val arr = JSONArray()
        for (e in list) {
            arr.put(JSONObject().put("f", e.from).put("t", e.to).put("s", e.source).put("r", e.result))
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
}
