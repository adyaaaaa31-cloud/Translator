package com.example.translator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TranslatorTheme { App() }
        }
    }
}

@Composable
fun TranslatorTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme()) {
        darkColorScheme(primary = Color(0xFF7FB2FF), onPrimary = Color(0xFF002B55))
    } else {
        lightColorScheme(primary = Color(0xFF1456B8))
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun App() {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    var from by rememberSaveable { mutableStateOf("en") }
    var to by rememberSaveable { mutableStateOf("hi") }
    var input by rememberSaveable { mutableStateOf("") }
    var output by rememberSaveable { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var copied by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf(Store.load(context)) }

    fun doTranslate() {
        val source = input.trim()
        if (source.isEmpty() || busy) return
        error = ""
        copied = false
        if (from == to) {
            output = source
            return
        }
        busy = true
        val f = from
        val t = to
        translateText(
            text = source,
            from = f,
            to = t,
            onResult = { result ->
                output = result
                busy = false
                history = (listOf(Entry(f, t, source, result)) + history).take(30)
                Store.save(context, history)
            },
            onError = { message ->
                error = message
                busy = false
            }
        )
    }

    Scaffold { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("Translator", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
            }

            item {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LanguagePicker(from, Modifier.weight(1f)) { from = it }
                    TextButton(onClick = {
                        val old = from
                        from = to
                        to = old
                        if (output.isNotEmpty()) {
                            input = output
                            output = ""
                        }
                    }) { Text("Swap") }
                    LanguagePicker(to, Modifier.weight(1f)) { to = it }
                }
            }

            item {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    label = { Text("Type or paste text in ${langName(from)}") },
                    minLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { doTranslate() },
                        enabled = input.isNotBlank() && !busy,
                        modifier = Modifier.weight(1f)
                    ) { Text(if (busy) "Translating..." else "Translate") }
                    OutlinedButton(onClick = {
                        input = ""
                        output = ""
                        error = ""
                    }) { Text("Clear") }
                }
            }

            if (busy) {
                item {
                    Text(
                        "The first time you use a language, a small language pack (about 30 MB) is downloaded. Keep your internet on.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (error.isNotEmpty()) {
                item { Text(error, color = MaterialTheme.colorScheme.error) }
            }

            if (output.isNotEmpty()) {
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(langName(to), style = MaterialTheme.typography.labelMedium)
                            Text(output, style = MaterialTheme.typography.bodyLarge)
                            TextButton(onClick = {
                                clipboard.setText(AnnotatedString(output))
                                copied = true
                            }) { Text(if (copied) "Copied" else "Copy") }
                        }
                    }
                }
            }

            if (history.isNotEmpty()) {
                item {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Recent", style = MaterialTheme.typography.titleMedium)
                        TextButton(onClick = {
                            history = emptyList()
                            Store.save(context, history)
                        }) { Text("Clear history") }
                    }
                }
                items(history) { e ->
                    Card(
                        Modifier.fillMaxWidth().clickable {
                            from = e.from
                            to = e.to
                            input = e.source
                            output = e.result
                            error = ""
                        }
                    ) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("${langName(e.from)} to ${langName(e.to)}", style = MaterialTheme.typography.labelSmall)
                            Text(e.source, maxLines = 2, style = MaterialTheme.typography.bodyMedium)
                            Text(
                                e.result,
                                maxLines = 2,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LanguagePicker(code: String, modifier: Modifier = Modifier, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Text(langName(code), maxLines = 1)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            for (lang in LANGS) {
                DropdownMenuItem(
                    text = { Text(lang.second) },
                    onClick = {
                        onPick(lang.first)
                        open = false
                    }
                )
            }
        }
    }
}
