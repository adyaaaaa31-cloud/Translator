package com.example.translator

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions

/**
 * Translates text on the phone with Google ML Kit.
 * The first time a language is used, its language pack (about 30 MB) is downloaded, so internet is needed once.
 * After that it works offline. Results come back on the main thread.
 */
fun translateText(
    text: String,
    from: String,
    to: String,
    onResult: (String) -> Unit,
    onError: (String) -> Unit
) {
    val options = TranslatorOptions.Builder()
        .setSourceLanguage(from)
        .setTargetLanguage(to)
        .build()
    val translator = Translation.getClient(options)

    translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
        .addOnSuccessListener {
            translator.translate(text)
                .addOnSuccessListener { result ->
                    onResult(result)
                    translator.close()
                }
                .addOnFailureListener { error ->
                    onError(error.message ?: "Translation failed. Please try again.")
                    translator.close()
                }
        }
        .addOnFailureListener {
            onError("Could not download the language pack. Check your internet and try again.")
            translator.close()
        }
}
